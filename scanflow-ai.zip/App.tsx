import React, { useState } from 'react';
import Scanner from './components/Scanner';
import ResultCard from './components/ResultCard';
import SettingsModal from './components/SettingsModal';
import { analyzeScanContent } from './services/geminiService';
import { ScanResult, AIAnalysisResult, WebhookConfig, ScanStatus } from './types';
import { ScanLine, Settings, Zap } from 'lucide-react';

const App: React.FC = () => {
  const [scanStatus, setScanStatus] = useState<ScanStatus>(ScanStatus.IDLE);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [aiResult, setAiResult] = useState<AIAnalysisResult | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  
  // Configuração persistente (simulada)
  const [webhookConfig, setWebhookConfig] = useState<WebhookConfig>({
    urlTemplate: '',
    enabled: false
  });

  const handleScanSuccess = async (text: string, result: any) => {
    setScanStatus(ScanStatus.SUCCESS);
    setScanResult({
      decodedText: text,
      decodedResult: result,
      format: result?.format?.formatName
    });

    // Iniciar análise IA
    const analysis = await analyzeScanContent(text);
    setAiResult(analysis);
  };

  const handleReset = () => {
    setScanStatus(ScanStatus.IDLE);
    setScanResult(null);
    setAiResult(null);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center p-4 font-sans">
      
      {/* Top Bar */}
      <div className="w-full max-w-md flex justify-between items-center mb-8 pt-2">
        <div className="flex items-center gap-2">
          <div className="bg-cyan-500 p-2 rounded-lg shadow-lg shadow-cyan-500/20">
            <ScanLine size={24} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              ScanFlow AI
            </h1>
            <p className="text-xs text-slate-400">Inteligência Artificial Integrada</p>
          </div>
        </div>
        <button 
          onClick={() => setShowSettings(true)}
          className="p-2 bg-slate-800 rounded-full hover:bg-slate-700 transition-colors border border-slate-700"
        >
          <Settings size={20} className="text-slate-300" />
        </button>
      </div>

      {/* Main Content Area */}
      <div className="w-full max-w-md flex-1 flex flex-col items-center justify-start gap-6">
        
        {scanStatus === ScanStatus.IDLE && (
          <div className="w-full flex flex-col items-center animate-fade-in-up">
            <div className="mb-6 text-center">
              <p className="text-slate-300 mb-2">Pronto para escanear</p>
              <div className="flex items-center justify-center gap-2 text-xs text-slate-500 bg-slate-800/50 px-3 py-1 rounded-full">
                <Zap size={12} className="text-yellow-500" />
                <span>Motor: html5-qrcode (Nativo)</span>
              </div>
            </div>
            
            <Scanner onScanSuccess={handleScanSuccess} />
            
            <p className="mt-8 text-xs text-slate-500 text-center max-w-[250px]">
              Aponte a câmera para um QR Code ou código de barras. A IA analisará o conteúdo automaticamente.
            </p>
          </div>
        )}

        {scanStatus === ScanStatus.SUCCESS && scanResult && (
          <ResultCard 
            scannedText={scanResult.decodedText}
            aiResult={aiResult}
            isLoadingAI={!aiResult}
            webhookConfig={webhookConfig}
            onReset={handleReset}
            onConfigureWebhook={() => setShowSettings(true)}
          />
        )}
      </div>

      {/* Modals */}
      {showSettings && (
        <SettingsModal 
          config={webhookConfig}
          onSave={setWebhookConfig}
          onClose={() => setShowSettings(false)}
        />
      )}

      {/* Footer */}
      <div className="mt-auto py-6 text-center">
        <p className="text-xs text-slate-600">
          Powered by Google Gemini & Vercel
        </p>
      </div>
    </div>
  );
};

export default App;