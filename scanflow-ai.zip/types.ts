export enum ScanStatus {
  IDLE = 'IDLE',
  SCANNING = 'SCANNING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}

export interface ScanResult {
  decodedText: string;
  decodedResult: any;
  format?: string; // e.g., QR_CODE, EAN_13
}

export interface WebhookConfig {
  urlTemplate: string; // e.g., "myapp://add?id={CODE}"
  enabled: boolean;
}

export interface AIAnalysisResult {
  summary: string;
  category: string;
  actionSuggestion: string;
}
