import { GoogleGenAI, Type } from "@google/genai";
import { AIAnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeScanContent = async (content: string): Promise<AIAnalysisResult> => {
  try {
    const prompt = `Analyze the following scanned data from a QR code or barcode: "${content}".
    
    Determine:
    1. A short summary or product name (if it's a barcode).
    2. The category (e.g., URL, Product, Contact Info, Wi-Fi, Plain Text).
    3. A suggested action (e.g., "Open Website", "Search Product", "Save Contact").
    
    Return in JSON format.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            category: { type: Type.STRING },
            actionSuggestion: { type: Type.STRING }
          },
          required: ["summary", "category", "actionSuggestion"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as AIAnalysisResult;

  } catch (error) {
    console.error("Error analyzing scan:", error);
    return {
      summary: "Não foi possível analisar",
      category: "Desconhecido",
      actionSuggestion: "Copiar"
    };
  }
};