import React from 'react';
import { AIAnalysisResult, WebhookConfig } from '../types';
import { Copy, Share2, ExternalLink, ArrowRight, Loader2, Settings } from 'lucide-react';

interface ResultCardProps {
  scannedText: string;
  aiResult: AIAnalysisResult | null;
  isLoadingAI: boolean;
  webhookConfig: WebhookConfig;
  onReset: () => void;
  onConfigureWebhook: () => void;
}

const ResultCard: React.FC<ResultCardProps> = ({ 
  scannedText, 
  aiResult, 
  isLoadingAI, 
  webhookConfig,
  onReset,
  onConfigureWebhook
}) => {
  
  const handleCopy = () => {
    navigator.clipboard.writeText(scannedText);
    alert('Texto copiado!');
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Código Escaneado',
          text: scannedText,
        });
      } catch (err) {
        console.log('Error sharing', err);
      }
    } else {
      handleCopy();
    }
  };

  const executeWebhook = () => {
    if (!webhookConfig.urlTemplate) return;
    const url = webhookConfig.urlTemplate.replace('{CODE}', encodeURIComponent(scannedText));
    window.open(url, '_blank');
  };

  const isUrl = (text: string) => {
    try {
      new URL(text);
      return true;
    } catch {
      return false;
    }
  };

  return (
    <div className="w-full max-w-md bg-slate-800 border border-slate-700 rounded-2xl shadow-xl p-6 flex flex-col gap-6 animate-fade-in-up">
      
      {/* Header */}
      <div className="flex justify-between items-center border-b border-slate-700 pb-4">
        <h2 className="text-xl font-bold text-white">Resultado</h2>
        <button 
          onClick={onReset}
          className="text-sm text-cyan-400 hover:text-cyan-300 transition-colors"
        >
          Escanear Novo
        </button>
      </div>

      {/* Raw Content */}
      <div className="bg-slate-900 rounded-xl p-4 border border-slate-700 break-all">
        <label className="text-xs uppercase tracking-wider text-slate-500 font-semibold mb-1 block">
          Conteúdo Bruto
        </label>
        <p className="text-lg text-emerald-400 font-mono">{scannedText}</p>
      </div>

      {/* AI Analysis Section */}
      <div className="bg-slate-700/30 rounded-xl p-4 border border-slate-600">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-2 h-2 rounded-full bg-purple-500 animate-pulse"></div>
          <span className="text-sm font-semibold text-purple-300">Análise Inteligente Gemini</span>
        </div>

        {isLoadingAI ? (
          <div className="flex items-center gap-2 text-slate-400 py-2">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span className="text-sm">Processando dados...</span>
          </div>
        ) : aiResult ? (
          <div className="space-y-2">
            <div className="flex justify-between items-start">
              <span className="text-slate-400 text-sm">Categoria:</span>
              <span className="text-white text-sm font-medium bg-slate-600 px-2 py-0.5 rounded">
                {aiResult.category}
              </span>
            </div>
            <div>
              <p className="text-slate-200 font-medium">{aiResult.summary}</p>
            </div>
            {aiResult.actionSuggestion && (
              <div className="pt-2">
                <span className="text-xs text-slate-400">Sugestão: </span>
                <span className="text-xs text-purple-300">{aiResult.actionSuggestion}</span>
              </div>
            )}
          </div>
        ) : (
          <p className="text-sm text-red-400">Falha na análise.</p>
        )}
      </div>

      {/* Actions Grid */}
      <div className="grid grid-cols-2 gap-3">
        <button 
          onClick={handleCopy}
          className="flex items-center justify-center gap-2 bg-slate-700 hover:bg-slate-600 text-white py-3 px-4 rounded-xl transition-all"
        >
          <Copy size={18} />
          <span>Copiar</span>
        </button>

        <button 
          onClick={handleShare}
          className="flex items-center justify-center gap-2 bg-slate-700 hover:bg-slate-600 text-white py-3 px-4 rounded-xl transition-all"
        >
          <Share2 size={18} />
          <span>Enviar</span>
        </button>

        {isUrl(scannedText) && (
          <a 
            href={scannedText} 
            target="_blank" 
            rel="noopener noreferrer"
            className="col-span-2 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white py-3 px-4 rounded-xl transition-all shadow-lg shadow-blue-900/50"
          >
            <ExternalLink size={18} />
            <span>Abrir Link</span>
          </a>
        )}

        {/* Integration Button */}
        {webhookConfig.enabled && webhookConfig.urlTemplate && (
          <button 
            onClick={executeWebhook}
            className="col-span-2 flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white py-3 px-4 rounded-xl transition-all shadow-lg shadow-emerald-900/50"
          >
            <ArrowRight size={18} />
            <span>Enviar para App Externo</span>
          </button>
        )}
      </div>

      <div className="border-t border-slate-700 pt-4 flex justify-center">
         <button onClick={onConfigureWebhook} className="text-xs text-slate-500 flex items-center gap-1 hover:text-slate-300">
            <Settings size={12} /> Configurar Integração
         </button>
      </div>
    </div>
  );
};

export default ResultCard;