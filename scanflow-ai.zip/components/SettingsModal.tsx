import React, { useState } from 'react';
import { WebhookConfig } from '../types';
import { X, Save } from 'lucide-react';

interface SettingsModalProps {
  config: WebhookConfig;
  onSave: (config: WebhookConfig) => void;
  onClose: () => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ config, onSave, onClose }) => {
  const [url, setUrl] = useState(config.urlTemplate);
  const [enabled, setEnabled] = useState(config.enabled);

  const handleSave = () => {
    onSave({ urlTemplate: url, enabled });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
      <div className="bg-slate-800 rounded-2xl w-full max-w-md border border-slate-700 shadow-2xl p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-white">Integração Externa</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X size={24} />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              URL Scheme / Webhook
            </label>
            <p className="text-xs text-slate-500 mb-2">
              Use <code>{'{CODE}'}</code> onde o valor escaneado deve ser inserido.
            </p>
            <input 
              type="text" 
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="ex: estoque://add?ean={CODE}"
              className="w-full bg-slate-900 border border-slate-600 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-3">
             <input 
              type="checkbox" 
              id="enableWebhook"
              checked={enabled}
              onChange={(e) => setEnabled(e.target.checked)}
              className="w-5 h-5 rounded border-slate-600 bg-slate-900 text-cyan-600 focus:ring-cyan-500"
             />
             <label htmlFor="enableWebhook" className="text-slate-300">Habilitar botão de envio</label>
          </div>
        </div>

        <div className="mt-8">
          <button 
            onClick={handleSave}
            className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
          >
            <Save size={18} />
            Salvar Configuração
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;